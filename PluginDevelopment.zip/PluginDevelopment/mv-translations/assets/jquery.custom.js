jQuery(document).ready(function(){
    jQuery("#translations-form").validate();
});